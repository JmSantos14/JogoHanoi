// TorreHanoi
package frontend;

import java.util.ArrayList;
import java.util.Scanner;

import backend.Regras;
import backend.TabuleiroEstatico;
import backend.TabuleiroHanoi;
import console.Console;

public class TorreHanoi {
    private int disco = 5;
    private int movimentos = 0;
    private ArrayList<Integer> torre1 = new ArrayList<>();
    private ArrayList<Integer> torre2 = new ArrayList<>();
    private ArrayList<Integer> torre3 = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);
    private TabuleiroHanoi tabuleiro;
    private static TorreHanoi jogoAtual = null;


    public TorreHanoi() {
        tabuleiro = new TabuleiroHanoi();
    }

    public void init() {
        for (int i = 0; i < disco; i++) {
            torre1.add(i + 1);
        }
        for (int i = 0; i < disco; i++) {
            int disco = torre1.get(i);
            switch (disco) {
                case 1:
                    torre1.set(i, 5);
                    break;
                case 2:
                    torre1.set(i, 4);
                    break;
                case 3:
                    torre1.set(i, 3);
                    break;
                case 4:
                    torre1.set(i, 2);
                    break;
                case 5:
                    torre1.set(i, 1);
                    break;
                default:
                    break;
            }
        }
    }

    public String movimentar(int aroOrigem, int aroDestino) {
        ArrayList<Integer> origem = getTorre(aroOrigem);
        ArrayList<Integer> destino = getTorre(aroDestino);

        if (origem.isEmpty()) {
            System.out.println("\nA Torre de Origem está Vazia.");
            return " ";
        }
        if (!destino.isEmpty() && origem.get(origem.size() - 1) > destino.get(destino.size() - 1)) {
            System.out.println("\nVocê Não Pode Mover um Disco Maior para Cima de um Disco Menor.");
            return " ";
        }
        int disco = origem.remove(origem.size() - 1);
        destino.add(disco);

        System.out.println("\nMovendo disco " + disco + " da torre " + aroOrigem + " para a torre " + aroDestino);
        tabuleiro.atualizar(torre1, torre2, torre3);

        return String.valueOf(disco);
    }

    private ArrayList<Integer> getTorre(int torre) {
        switch (torre) {
            case 1:
                return torre1;
            case 2:
                return torre2;
            case 3:
                return torre3;
            default:
                return new ArrayList<>();
        }
    }

    public void inputValue() {
        int aroOrigem = 0;
        int aroDestino = 0;
        System.out.println("\nAperte P para Pausar");
        System.out.print("Informe a Torre de Origem (1, 2, 3): ");
        while (true) {
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("P")) {
                pause();
                continue;
            }
            try {
                aroOrigem = Integer.parseInt(input);
                if (aroOrigem < 1 || aroOrigem > 3) {
                    System.out.println("Torre Invalida. Informe Novamente.");
                } else {
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada Inválida. Informe Novamente.");
            }
        }

        System.out.print("Informe a Torre de Destino (1, 2, 3): ");
        while (true) {
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("P")) {
                pause();
                continue;
            }
            try {
                aroDestino = Integer.parseInt(input);
                if (aroDestino < 1 || aroDestino > 3) {
                    System.out.println("Torre Invalida. Informe Novamente.");
                } else {
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada Invalida. Informe Novamente.");
            }
        }

        String movimento = movimentar(aroOrigem, aroDestino);
        if (!movimento.isEmpty()) {
            movimentos++;
            System.out.println("\nMovimentos: " + movimentos);
        }
        if (validaResultado()) {
            fimJogo();
        } else {
            inputValue();
        }
    }

    public boolean validaResultado() {
        return torre1.isEmpty() && (torre2.isEmpty() || torre3.isEmpty()) && (torre2.size() == disco || torre3.size() == disco);
    }

    public void fimJogo() {
        FimMenu fimmenu = new FimMenu();
        Console.println(fimmenu);
        System.out.println("PARABÉNS, VOCÊ GANHOU!");
        System.out.print("Para uma Nova Partida, Digite Iniciar ");
        if (scanner.nextLine().equalsIgnoreCase("Iniciar")) {
            init();
        } else {
            System.out.println("Que Pena, Então Até a Próxima");
            System.exit(0);
        }
    }

    public void iniciar() {
        movimentos = 0;
        torre1.clear();
        torre2.clear();
        torre3.clear();

        init();
        System.out.println("*Vamos Iniciar o Jogo*");
        inputValue();
    }

    public void pause() {
        PauseMenu Pause = new PauseMenu();
        Console.println(Pause);
        Scanner escolhaP = new Scanner(System.in);
        int selecaoP;
        do {
            Console.println("");
            System.out.println("1 - Voltar para o Jogo");
            System.out.println("2 - Voltar para o Menu Principal");
            System.out.print("  ✨Escolha: ");

            selecaoP = escolhaP.nextInt();

            if (selecaoP == 1) {
                System.out.println("Voltando ao Jogo");
                jogoAtual.inputValue();
            } else if (selecaoP == 2) {
                System.out.println("Voltando ao Menu Principal");
                mainMenu();
            } else {
                System.out.println("Opção Inválida");
            }
        } while (selecaoP != 1 && selecaoP != 2);
    }

    public static void mainMenu() {
        Menu menu = new Menu();
        Scanner escolha = new Scanner(System.in);
        int selecao;
        do {
            Console.println("");
            Console.println(menu);
            System.out.println("1 - Continuar Jogo Atual");
            System.out.println("2 - Iniciar Novo Jogo");
            System.out.println("3 - Regras");
            System.out.println("4 - Sair do Jogo");
            System.out.print("  ✨Escolha: ");

            selecao = escolha.nextInt();

            if (selecao == 1) {
                if (jogoAtual != null) {
                    Console.println("Continuando Jogo Atual");
                    Console.println(jogoAtual.tabuleiro);
                    jogoAtual.inputValue();
                } else {
                    Console.println("Nenhum Jogo em Andamento. Inicie um Novo Jogo.");
                }
            } else if (selecao == 2) {
                Console.println("Iniciando Novo Jogo");
                TabuleiroEstatico tab2 = new TabuleiroEstatico();
                Console.println(tab2);
                jogoAtual = new TorreHanoi();
                jogoAtual.iniciar();
            } else if (selecao == 3) {
                Regras regras = new Regras();
                Console.println("");
                Console.println(regras);
                System.out.println("Pressione Enter para Voltar ao Menu");
                escolha.nextLine();
                escolha.nextLine();
            } else if (selecao == 4) {
                Console.println("Saindo do Jogo");
                System.exit(0);
            } else {
                Console.println("Opção Inválida");
            }
        } while (selecao != 4);
        escolha.close();
    }
}
