// Menu
package frontend;

import cores.StringColorida;
import mecanicas.Tabuleiro;
import backend.Peca;
import console.Console;

public class FimMenu extends Tabuleiro {
    private FimMenu FimMenu;

    StringColorida Tamanho1 = new StringColorida("\u0000", "azul_claro", "preto");
    Peca aro1 = new Peca(Tamanho1);


    StringColorida Tamanho6 = new StringColorida("\ua57a", "branco", "preto");
    Peca estrela1 = new Peca(Tamanho6);


    public FimMenu() {
        super(7, 45, new Peca(new StringColorida(" ")));

        //Letra P
        for (int i = 1; i < 6; i++) {
            setFundo(i, 11, aro1);
            if (i > 1 && i < 9) {
                for (int n = 13; n < 17; n++) {
                    setFundo(1, n, aro1);
                }
                if (i > 1 && i < 9) {
                    for (int n = 13; n < 17; n++) {
                        setFundo(3, n, aro1);
                    }
                }
            }
        }


//Letra I
        for (int i = 1; i < 6; i++) {
            if (i == 1) {
                for (int a = 19; a < 24; a++) {
                    setFundo(i, a, aro1);
                }
            }
            if (i == 5) {
                for (int a = 19; a < 24; a++) {
                    setFundo(i, a, aro1);
                }
            }
        }
        for (int i = 2; i < 5; i++) {
            setFundo(i, 21, aro1);
        }
        // Letra M
        for (int i = 1; i < 6; i++) {
            setFundo(i, 25, aro1);
            setFundo(i, 35, aro1);
            if (i == 2) {
                setFundo(1, 26, aro1);
                setFundo(2, 27, aro1);
                setFundo(3, 28, aro1);
                setFundo(4, 29, aro1);
                setFundo(5, 30, aro1);

                setFundo(4, 31, aro1);
                setFundo(3, 32, aro1);
                setFundo(2, 33, aro1);
                setFundo(1, 34, aro1);
            }
        }
            //Borda
            int b = 2;
            for (int i = 1; i < 6; i++) {
                setFundo(i, 0, estrela1);
                setFundo(i, 44, estrela1);
                if (i == 1) {
                    for (int k = 0; k < 45; k = k + 2) {
                        setFundo(0, k, estrela1);
                        setFundo(6, k, estrela1);
                    }
                }
            }
        }
    }


