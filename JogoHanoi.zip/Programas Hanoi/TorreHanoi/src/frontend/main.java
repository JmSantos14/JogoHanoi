// Main
package frontend;

import console.Console;

import static frontend.TorreHanoi.mainMenu;

public class main {
    private TorreHanoi mainMenu;

    //Aonde todo o jogo roda
    public static void main(String[] args) {
        mainMenu();
    }
}


