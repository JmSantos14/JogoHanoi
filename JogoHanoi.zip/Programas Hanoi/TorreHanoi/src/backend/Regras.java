// Regras
// Referencia do Site: somatematica
package backend;
import console.Console;
import cores.StringColorida;
import mecanicas.Tabuleiro;

public class Regras extends Tabuleiro {
    StringColorida resumo = new StringColorida("\nSó é Possível Mover um Quadrado por Vez" +
            "\nUm Quadrado Maior Nunca Pode ser Colocado Sobre um Quadrado Menor" +
            "\nApenas o Quadrado no Topo de Qualquer Torre Pode ser Movido"
            ,"azul", "preto");
    Peca res = new Peca(resumo);

    StringColorida o = new StringColorida("Objetivo:", "rosa", "preto");

    StringColorida j = new StringColorida("\nEscolha a Torre de Origem que Deseja Mover o Quadrado do Topo\n" +
            "e Selecione a Torre Destino"
            ,"BRANCO_BRANCO", "preto");
    Peca jogadas = new Peca(j);
    public Regras() {
        super(0, 0, new Peca(new StringColorida(" ")));
        Console.println(res);
        Console.println("\n✨"+ o+" Mover Todos os Quadrados para o Pino Mais a Direita.");
        Console.println(jogadas);
    }
}
