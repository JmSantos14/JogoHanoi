// Menu
package frontend;

import cores.StringColorida;
import mecanicas.Tabuleiro;
import backend.Peca;
import console.Console;

public class Menu extends Tabuleiro {
    private Menu Menu;
    StringColorida Linha1 = new StringColorida("|", "branco", "preto");
    Peca linha1 = new Peca(Linha1);

    StringColorida Tamanho1 = new StringColorida("\u0000", "verde", "preto");
    Peca aro1 = new Peca(Tamanho1);

    StringColorida Tamanho2 = new StringColorida("\u0000", "roxo", "preto");
    Peca aro2 = new Peca(Tamanho2);

    StringColorida Tamanho3 = new StringColorida("\u0000", "azul", "preto");
    Peca aro3 = new Peca(Tamanho3);

    StringColorida Tamanho4 = new StringColorida("\u0000", "vermelho", "preto");
    Peca aro4 = new Peca(Tamanho4);

    StringColorida Tamanho5 = new StringColorida("\u0000", "amarelo", "preto");
    Peca aro5 = new Peca(Tamanho5);

    StringColorida Tamanho6 = new StringColorida("\ua57a", "branco", "preto");
    Peca estrela1 = new Peca(Tamanho6);


    public Menu() {
        super(7, 45, new Peca(new StringColorida(" ")));

        //Letra H
        for (int i = 1; i < 6; i++) {
            setFundo(i,3,aro1);
            setFundo(i, 9, aro1);
            if (i > 3 && i < 9) {
                for (int n = 4; n < 9; n++) {
                    setFundo(3, n, aro1);
                }
            }
        }
        //Letra A
        int j = 15;
        for (int i = 1; i < 6; i++) {
            setFundo(i,j,aro2);
            if (j > 13 && j < 16){
                setFundo(3,j,aro2);
            }
            j = j - 1;
        }
        int m = 16;
        for (int n = 1; n < 6; n++) {
            setFundo(n,m,aro2);
            if (m > 15 && m < 18){
                setFundo(3,m,aro2);
            }
            m = m + 1;
        }

        // Letra N
        for (int i = 1; i < 6; i++) {
            setFundo(i,22,aro3);
            setFundo(i,27,aro3);
            if (i == 2) {
                setFundo(2,23,aro3);
                setFundo(3, 24, aro3);
                setFundo(4, 25, aro3);
            }
        }

        //Letra O
        for (int i = 1; i < 6; i++) {
            if (i == 1) {
                for (int k = 30; k < 35; k++) {
                    setFundo(i, k, aro4);
                }
            }
            if (i == 5) {
                for (int k = 30; k < 35; k++) {
                    setFundo(i, k, aro4);
                }
            }
        }
        for (int i = 2; i < 5; i++) {
            setFundo(i, 29, aro4);
            setFundo(i, 35, aro4);
        }

        //Letra I
        for (int i = 1; i < 6; i++) {
            if (i==1){
                for (int a = 37; a < 42; a++) {
                    setFundo(i,a,aro5);
                }
            }
            if (i==5){
                for (int a = 37; a < 42; a++) {
                    setFundo(i,a,aro5);
                }
            }
        }
        for (int i = 2; i < 5; i++) {
            setFundo(i, 39, aro5);
        }

        //Borda
        int b = 2;
        for (int i = 1; i < 6; i++) {
            setFundo(i, 0, estrela1);
            setFundo(i, 44, estrela1);
            if (i == 1){
                for (int k = 0; k < 45; k = k+2) {
                    setFundo(0,k,estrela1);
                    setFundo(6,k,estrela1);
                }
            }
        }
    }

    // Teste do Menu
    public static void main(String[] args) {
        Menu tab = new Menu();
        Console.println("");
        Console.print(tab);
        }
}
