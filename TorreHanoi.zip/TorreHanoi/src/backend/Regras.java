// Regras
// Referencia do Site: somatematica
package backend;
import console.Console;
import cores.StringColorida;
import mecanicas.Tabuleiro;

public class Regras extends Tabuleiro {
    StringColorida resumo = new StringColorida("\nSó é Possível Mover um Disco por Vez" +
            "\nUm Disco Maior Nunca Pode ser Colocado Sobre um Disco Menor" +
            "\nApenas o Disco no Topo de Qualquer Torre Pode ser Movido"
            ,"azul", "preto");
    Peca res = new Peca(resumo);

    StringColorida o = new StringColorida("Objetivo:", "rosa", "preto");

    StringColorida j = new StringColorida("\nEscolha a Torre de Origem que Deseja Mover o Aro do Topo\n" +
            "e Selecione a Torre Destino"
            ,"amarelo", "preto");
    Peca jogadas = new Peca(j);
    public Regras() {
        super(0, 0, new Peca(new StringColorida(" ")));
        Console.println(res);
        Console.println("\n✨"+ o+" Mover Todos os Discos para o Pino Mais a Direita.");
        Console.println(jogadas);
    }
    public static void main(String[] args) {
        Regras r = new Regras();
        Console.println(r);
    }

}
