package backend;

import cores.StringColorida;
import mecanicas.Carta;

public class Peca extends Carta {
    private StringColorida cor;

    public Peca(StringColorida frente, StringColorida cor) {
        super(frente);
        this.cor = cor;
    }

    public Peca(StringColorida linha1) {
        super(linha1);
        this.cor = linha1;
    }

    public StringColorida getCor() {
        return cor;
    }
}
