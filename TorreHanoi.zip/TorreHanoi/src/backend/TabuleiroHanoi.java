package backend;

import console.Console;
import cores.StringColorida;
import mecanicas.Tabuleiro;

import java.util.ArrayList;

public class TabuleiroHanoi extends Tabuleiro {
    //Declaracao de aros
    private Peca aro1;
    private Peca aro2;
    private Peca aro3;
    private Peca aro4;
    private Peca aro5;

    //Caracteristicas para as Torres
    StringColorida N1 = new StringColorida("Torre 1        Torre 2        Torre 3   ", "ciano", "preto");

    //Caracteristicas para os Aros
    StringColorida frenteDisco1 = new StringColorida("\u0000", "verde", "preto");
    StringColorida frenteDisco2 = new StringColorida("\u0000", "roxo", "preto");
    StringColorida frenteDisco3 = new StringColorida("\u0000", "azul", "preto");
    StringColorida frenteDisco4 = new StringColorida("\u0000", "vermelho", "preto");
    StringColorida frenteDisco5 = new StringColorida("\u0000", "amarelo", "preto");

    //Caracteristicas para as Linhas
    StringColorida corLinha = new StringColorida("|", "branco", "preto");
    Peca linha1 = new Peca(corLinha);


    public TabuleiroHanoi() {
        super(5, 40, new Peca(new StringColorida(" ")));
        aro1 = new Peca(frenteDisco1);
        aro2 = new Peca(frenteDisco2);
        aro3 = new Peca(frenteDisco3);
        aro4 = new Peca(frenteDisco4);
        aro5 = new Peca(frenteDisco5);

        // Configuracao inicial das torres
        for (int i = 0; i < 5; i++) {
            setFundo(i, 2, linha1);
            setFundo(i, 17, linha1);
            setFundo(i, 32, linha1);
        }
    }

    public void atualizar(ArrayList<Integer> torre1, ArrayList<Integer> torre2, ArrayList<Integer> torre3) {
        limparTabuleiro();
        atualizarTorre(torre1, 0);
        atualizarTorre(torre2, 1);
        atualizarTorre(torre3, 2);
        exibirTabuleiro();
    }

    private void limparTabuleiro() {
        int linhas = 5;
        for (int i = 0; i < linhas; i++) {
            int colunas = 40;
            for (int j = 0; j < colunas; j++) {
                setFundo(i, j, new Peca(new StringColorida(" ")));
            }
        }
        // Redesenhando as linhas verticais
        for (int i = 0; i < 5; i++) {
            setFundo(i, 2, linha1);
            setFundo(i, 17, linha1);
            setFundo(i, 32, linha1);
        }
    }
    //Atualiza o tabuleiro apos um movimento
    private void atualizarTorre(ArrayList<Integer> torre, int coluna) {
        int linhas = 5; // Valor fixo assumindo 5 linhas
        int tamanhoMaximoDisco = 5; // Tamanho máximo dos discos

        for (int i = 0; i < torre.size(); i++) {
            int disco = torre.get(i);
            Peca discoPeca = null;

            switch (disco) {
                case 1:
                    discoPeca = aro1;
                    break;
                case 2:
                    discoPeca = aro2;
                    break;
                case 3:
                    discoPeca = aro3;
                    break;
                case 4:
                    discoPeca = aro4;
                    break;
                case 5:
                    discoPeca = aro5;
                    break;
                default:
                    break;
            }

            if (discoPeca != null) {
                // Ajusta a posição do disco de acordo com seu tamanho
                int posicaoInicial = (disco - 2) / 4; // Calcula a posição inicial para centralizar o disco
                int posicaoFinal = posicaoInicial + disco - 1 ; // Calcula a posição final do disco na coluna
                for (int j = posicaoInicial; j <= posicaoFinal; j++) {
                    setFundo(linhas - i - 1, (coluna * 15) + 2 + j, discoPeca);
                }
            }
        }
    }
    // Exibe o tabuleiro atualizado
    private void exibirTabuleiro() {
        Console.println(N1);
        System.out.println(this);
    }
}
