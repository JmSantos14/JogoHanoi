//TabuleiroHanoi
package backend;

import cores.StringColorida;
import mecanicas.Tabuleiro;
import console.Console;

public class TabuleiroEstatico extends Tabuleiro{

    StringColorida N1 = new StringColorida("Torre 1      Torre 2      Torre 3", "ciano", "preto");

    StringColorida Linha1 = new StringColorida("|", "branco", "preto");
    Peca linha1 = new Peca(Linha1);

    StringColorida Tamanho1 = new StringColorida("\u0000", "verde", "preto");
    Peca aro1 = new Peca(Tamanho1);

    StringColorida Tamanho2 = new StringColorida("\u0000", "roxo", "preto");
    Peca aro2 = new Peca(Tamanho2);

    StringColorida Tamanho3 = new StringColorida("\u0000", "azul", "preto");
    Peca aro3 = new Peca(Tamanho3);

    StringColorida Tamanho4 = new StringColorida("\u0000", "vermelho", "preto");
    Peca aro4 = new Peca(Tamanho4);

    StringColorida Tamanho5 = new StringColorida("\u0000", "amarelo", "preto");
    Peca aro5 = new Peca(Tamanho5);

    public TabuleiroEstatico() {
        super(5, 33, new Peca(new StringColorida(" ")));

        Console.print("\nPressione ESC para pausar");
        Console.println("\n" + N1);

        setFundo(0, 2, linha1);
        setFundo(1, 2, linha1);
        setFundo(2, 2, linha1);
        setFundo(3, 2, linha1);
        setFundo(4, 2, linha1);

        setFundo(0, 17, linha1);
        setFundo(1, 17, linha1);
        setFundo(2, 17, linha1);
        setFundo(3, 17, linha1);
        setFundo(4, 17, linha1);

        setFundo(0, 32, linha1);
        setFundo(1, 32, linha1);
        setFundo(2, 32, linha1);
        setFundo(3, 32, linha1);
        setFundo(4, 32, linha1);

        for (int i = 2; i < 7; i++) {
            if (i < 7) {
                colocaCarta(4, i, aro5);
            }
            if (i < 6) {
                colocaCarta(3, i, aro4);
            }
            if (i < 5) {
                colocaCarta(2, i, aro3);
            }
            if (i < 4) {
                colocaCarta(1, i, aro2);
            }
            if (i < 3) {
                colocaCarta(0, i, aro1);
            }
        }
    }
}